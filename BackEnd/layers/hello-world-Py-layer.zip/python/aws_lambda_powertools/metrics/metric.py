# NOTE: prevents circular inheritance import
from .base import SingleMetric, single_metric

__all__ = ["SingleMetric", "single_metric"]
